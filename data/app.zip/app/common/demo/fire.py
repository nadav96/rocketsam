def fire():
    print "FIRE ZE MISSILES!"
