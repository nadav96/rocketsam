# DI:demo/fire


def hello():
    print "Hello world"
