import sys

sys.exit(1)